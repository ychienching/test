package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@Controller
public class SpringBootHelloWorld {
	
	
	//@RestController + @RequestMapping  在頁面直接return字串
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		SpringBootHelloWorld s = new SpringBootHelloWorld();

	}
	
//	void dosomething() {
//		
//		System.out.printf("do something: ", s.dosomething());
//		return;
//	}
	
	
	@RequestMapping("/x") // http://localhost:8080/demo/x
	//@GetMapping("/x")
	public String hello(){
		return "This is SpringBootHelloWorld";
	}
	
	@GetMapping("/index")// Spring Boot App >> http://localhost:8080/index/
	public String helloIndex(){ // Tomcat Server >> http://localhost:8080/demo/index
		return "index test";
	}
	
	@GetMapping("/index2")  // http://localhost:8080/index2成功連結，並導向index2.html
	public String helloIndex2(){
		return "index2 test from index2";
	}
	
	@GetMapping("/index3") // http://localhost:8080/index3成功連結，並導向index2.html
	public String helloIndex3(){
		return "index2 test from index3";
	}
	
//	@RequestMapping("/x")  //被要求所用接口
//	public String hello(){
//		return "Hey, Spring Boot 的 Hello World ! ";
//	}
//	
//	@RequestMapping("/index")
//	public String helloIndex(){
//		return "index";
//	}
	

}
