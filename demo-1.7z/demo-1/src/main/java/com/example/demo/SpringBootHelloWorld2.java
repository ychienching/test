package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/qqqq")
//@RequestMapping(value = "/qqqq", method = RequestMethod.GET)
public class SpringBootHelloWorld2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	@GetMapping("/xx")
	public String hello(){
		return "This is SpringBootHelloWorld2";
	}
	
	@GetMapping("/indexx") // Tomcat Server >> http://localhost:8080/demo/qq/indexx
	public String helloIndex(){
		return "index";
	}
	
	@GetMapping("/indexx2") // Tomcat Server >> http://localhost:8080/demo/qq/indexx2
	public String helloIndex2(){
		return "index2";
	}

}